// App.js
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Provider } from 'react-redux';
import ProfileScreen from './src/screens/ProfileScreen' 
import Editstudent from './src/screens/Editstudent';
import Editfac from './src/screens/Editfac';
import notificationScreen from './src/screens/notificationScreen';


import store from './src/Store';
import LoginScreen from './src/screens/LoginScreen';
import StudentStack from './src/navigation/StudentStack';
import AdminStack from './src/navigation/AdminStack';
import Invoices from './src/screens/Invoices';

import CourseAdd from './src/screens/CourseAdd';
import AddFac from './src/screens/AddFac';
import AddStudent from './src/screens/AddStudent';
import Course from './src/screens/Course';
import CourseDel from './src/screens/CourseDel';
import Courseinfo from './src/screens/Courseinfo';
import Dashbboard from './src/screens/Dashbboard'; 
import Dash from './src/screens/Dash';  
import Deletestudent from './src/screens/Deletestudent';
import DelFac from './src/screens/DelFac';
import Faculty from './src/screens/Faculty';
import FacultyInfo from './src/screens/FacultyInfo';
import Feature from './src/screens/Feature';
import Notf from './src/screens/Notf';
import StudentInfo from './src/screens/StudentInfo';
import Students from './src/screens/Students';
import Adminprof from './src/screens/Adminprof'

import CoursesScreen from './src/screens/CoursesScreen';
import AttendanceScreen from './src/screens/AttendanceScreen';
import InvoicesScreen from './src/screens/InvoicesScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <Provider store={store}>
      <NavigationContainer>
        <Stack.Navigator screenOptions={{ headerShown: false }}>
      
          <Stack.Screen name="Login" component={LoginScreen} />


          <Stack.Screen name="Student" component={StudentStack} />
          <Stack.Screen name="Admin" component={AdminStack} />

        
          <Stack.Screen name="AdminDashboard" component={Dashbboard} />
         
         <Stack.Screen name="Dash" component={Dash} />
        
          <Stack.Screen name="AddStudent" component={AddStudent} />
          <Stack.Screen name="AddFac" component={AddFac} />
          <Stack.Screen name="CourseAdd" component={CourseAdd} />
          <Stack.Screen name="Course" component={Course} />
          <Stack.Screen name="CourseDel" component={CourseDel} />
          <Stack.Screen name="Courseinfo" component={Courseinfo} />
          <Stack.Screen name="Deletestudent" component={Deletestudent} />
          <Stack.Screen name="DelFac" component={DelFac} />
          <Stack.Screen name="Faculty" component={Faculty} />
          <Stack.Screen name="FacultyInfo" component={FacultyInfo} />
          <Stack.Screen name="Feature" component={Feature} />
          <Stack.Screen name="Notf" component={Notf} />
          <Stack.Screen name="StudentInfo" component={StudentInfo} />
          <Stack.Screen name="Students" component={Students} />
          <Stack.Screen name="ProfileScreen" component={ProfileScreen} />
<Stack.Screen name="CoursesScreen" component={CoursesScreen} />
<Stack.Screen name="AttendanceScreen" component={AttendanceScreen} />
<Stack.Screen name="InvoicesScreen" component={InvoicesScreen} />
<Stack.Screen name="Invoices" component={Invoices} />
<Stack.Screen name="Editstudent" component={Editstudent} />
<Stack.Screen name="Editfac" component={Editfac} />
<Stack.Screen name="Adminprof" component={Adminprof} />
<Stack.Screen name="notificationScreen" component={notificationScreen} />

        </Stack.Navigator>
      </NavigationContainer>
    </Provider>
  );
}
