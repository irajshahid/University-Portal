
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

const SHEET_API_URL = 'https://api.sheetbest.com/sheets/560bd63f-eade-4c48-96da-452c0495857e';


export const fetchSheetData = createAsyncThunk(
  'portal/fetchSheetData',
  async () => {
    const response = await fetch(SHEET_API_URL);
    if (!response.ok) {
      throw new Error('Failed to fetch sheet data');
    }
    const data = await response.json();

 
    return Array.isArray(data.data) ? data.data : data;
  }
);

const portalSlice = createSlice({
  name: 'portal',
  initialState: {
    userType: null,       
    sheetData: [],     
    loading: false,     
    error: null,          
  },
  reducers: {
    setUserType: (state, action) => {
      state.userType = action.payload;
    },
    logout: (state) => {
      state.userType = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchSheetData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchSheetData.fulfilled, (state, action) => {
        state.loading = false;
        state.sheetData = action.payload;
      })
      .addCase(fetchSheetData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || 'Failed to fetch data';
      });
  },
});

export const { setUserType, logout } = portalSlice.actions;

export default portalSlice.reducer;
