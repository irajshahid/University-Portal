import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';

export default function AddCourse({ navigation }) {
  const [coursecode, setCoursecode] = useState('');
  const [coursetitle, setCoursetitle] = useState('');

  const endpoint = 'https://api.sheetbest.com/sheets/560bd63f-eade-4c48-96da-452c0495857e';

  const handleAddCourse = async () => {
    if (!coursecode || !coursetitle) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ coursecode, coursetitle }),
      });

      if (response.ok) {
        Alert.alert('Success', 'Course added');
        navigation.goBack();
      } else {
        Alert.alert('Error', 'Failed to add course');
      }
    } catch (err) {
      Alert.alert('Error', 'Failed to add course');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Add Course</Text>
      <TextInput
        style={styles.input}
        placeholder="Course Code"
        value={coursecode}
        onChangeText={setCoursecode}
      />
      <TextInput
        style={styles.input}
        placeholder="Course Title"
        value={coursetitle}
        onChangeText={setCoursetitle}
      />
      <TouchableOpacity style={styles.button} onPress={handleAddCourse}>
        <Text style={styles.buttonText}>Submit</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, backgroundColor: '#f4f6f7', flex: 1 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20, textAlign: 'center', color: '#0a3d62' },
  input: {
    backgroundColor: '#fff',
    padding: 12,
    marginBottom: 15,
    borderRadius: 10,
    borderColor: '#ccc',
    borderWidth: 1,
  },
  button: {
    backgroundColor: '#4a69bd',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 10,
  },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
});
