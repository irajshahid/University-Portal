import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  ActivityIndicator,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function DisplayFaculty({ navigation }) {
  const [facultyList, setFacultyList] = useState([]);
  const [filteredFaculty, setFilteredFaculty] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const endpoint = 'https://api.sheetbest.com/sheets/560bd63f-eade-4c48-96da-452c0495857e';

  useEffect(() => {
    const fetchFaculty = async () => {
      try {
        const response = await fetch(endpoint);
        const data = await response.json();
        setFacultyList(data);
        setFilteredFaculty(data);
      } catch (error) {
        alert('Failed to fetch faculty data');
      }
      setLoading(false);
    };

    fetchFaculty();
  }, []);

  const handleSearch = (text) => {
    setSearchTerm(text);
    if (text.trim() === '') {
      setFilteredFaculty(facultyList);
      return;
    }
    const filtered = facultyList.filter(
      (f) =>
        (f.FacId && f.FacId.toLowerCase().includes(text.toLowerCase())) ||
        (f.FacName && f.FacName.toLowerCase().includes(text.toLowerCase()))
    );
    setFilteredFaculty(filtered);
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Ionicons name="arrow-back" size={24} color="#1e3799" />
        <Text style={styles.backButtonText}>Back</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Faculty Info</Text>

      <TextInput
        style={styles.searchInput}
        placeholder="Search by ID or Name"
        value={searchTerm}
        onChangeText={handleSearch}
        autoCorrect={false}
        autoCapitalize="none"
        clearButtonMode="while-editing"
      />

      {loading ? (
        <ActivityIndicator size="large" color="#1e3799" style={{ marginTop: 20 }} />
      ) : filteredFaculty.length === 0 ? (
        <Text style={styles.noResultsText}>No faculty found.</Text>
      ) : (
        filteredFaculty.map((faculty, index) => (
          <View key={index} style={styles.card}>
            <Text style={styles.label}>
              ID: <Text style={styles.value}>{faculty.FacId}</Text>
            </Text>
            <Text style={styles.label}>
              Name: <Text style={styles.value}>{faculty.FacName}</Text>
            </Text>
            <Text style={styles.label}>
              Department: <Text style={styles.value}>{faculty.FacDept}</Text>
            </Text>
            <Text style={styles.label}>
              Designation: <Text style={styles.value}>{faculty.FacDesg}</Text>
            </Text>
            <Text style={styles.label}>
              Attendance: <Text style={styles.value}>{faculty.FacAtt}</Text>
            </Text>
            <Text style={styles.label}>
              Phone: <Text style={styles.value}>{faculty.FacPh}</Text>
            </Text>
            <Text style={styles.label}>
              Email: <Text style={styles.value}>{faculty.FacEmail}</Text>
            </Text>
          </View>
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#f2f4f7',
    flexGrow: 1,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  backButtonText: {
    marginLeft: 6,
    fontSize: 16,
    color: '#1e3799',
    fontWeight: '600',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#0a3d62',
    textAlign: 'center',
    marginBottom: 20,
  },
  searchInput: {
    backgroundColor: '#fff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#ced6e0',
  },
  noResultsText: {
    textAlign: 'center',
    color: '#8395a7',
    fontSize: 16,
    marginTop: 30,
  },
  card: {
    backgroundColor: '#dff9fb',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    elevation: 4,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#130f40',
    marginBottom: 4,
  },
  value: {
    fontWeight: '400',
    color: '#30336b',
  },
});
