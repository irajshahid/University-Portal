import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ActivityIndicator,
  ScrollView,
} from 'react-native';

const SHEETBEST_BASE_URL = 'https://api.sheetbest.com/sheets/560bd63f-eade-4c48-96da-452c0495857e';

const EditFaculty = ({ route, navigation }) => {
  const routeFacId = route?.params?.facId || '';
  const [facId, setFacId] = useState(routeFacId);

  const [loading, setLoading] = useState(false);
  const [updating, setUpdating] = useState(false);

  const [facName, setFacName] = useState('');
  const [facDept, setFacDept] = useState('');
  const [facDesg, setFacDesg] = useState('');
  const [facAtt, setFacAtt] = useState('');
  const [facPh, setFacPh] = useState('');
  const [facEmail, setFacEmail] = useState('');

  const [facultyLoaded, setFacultyLoaded] = useState(false);

  const fetchFaculty = async () => {
    if (!facId) {
      Alert.alert('Input Error', 'Please enter a faculty ID.');
      return;
    }

    try {
      setLoading(true);
      setFacultyLoaded(false);

      const response = await fetch(`${SHEETBEST_BASE_URL}?FacId=${facId}`);
      const data = await response.json();

      if (data.length === 0) {
        Alert.alert('Not found', `Faculty with ID ${facId} not found.`);
        return;
      }

      const faculty = data[0];
      setFacName(faculty.FacName || '');
      setFacDept(faculty.FacDept || '');
      setFacDesg(faculty.FacDesg || '');
      setFacAtt(faculty.FacAtt || '');
      setFacPh(faculty.FacPh || '');
      setFacEmail(faculty.FacEmail || '');

      setFacultyLoaded(true);
    } catch (error) {
      Alert.alert('Error', 'Failed to fetch faculty data.');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async () => {
    if (
      !facName ||
      !facDept ||
      !facDesg ||
      !facAtt ||
      !facPh ||
      !facEmail
    ) {
      Alert.alert('Validation', 'Please fill all fields.');
      return;
    }

    setUpdating(true);

    try {
      const response = await fetch(`${SHEETBEST_BASE_URL}/FacId/${facId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          FacName: facName,
          FacDept: facDept,
          FacDesg: facDesg,
          FacAtt: facAtt,
          FacPh: facPh,
          FacEmail: facEmail,
        }),
      });

      if (!response.ok) throw new Error('Update failed');

      Alert.alert('Success', 'Faculty info updated successfully.');
      navigation.goBack();
    } catch (error) {
      Alert.alert('Error', 'Failed to update faculty info.');
      console.error(error);
    } finally {
      setUpdating(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
      <Text style={styles.heading}>Edit Faculty Info</Text>

      {!routeFacId && (
        <>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Enter Faculty ID</Text>
            <TextInput
              value={facId}
              onChangeText={setFacId}
              placeholder="Enter faculty ID"
              style={styles.input}
              keyboardType="default"
              autoCapitalize="none"
              editable={!loading && !updating}
            />
          </View>

          <TouchableOpacity
            onPress={fetchFaculty}
            style={[styles.button, loading && { backgroundColor: '#7588c9' }]}
            disabled={loading || updating}
          >
            <Text style={styles.buttonText}>{loading ? 'Loading...' : 'Search'}</Text>
          </TouchableOpacity>
        </>
      )}

      {loading && (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color="#4a69bd" />
        </View>
      )}

      {facultyLoaded && !loading && (
        <>
          {[
            { label: 'Name', value: facName, setter: setFacName, placeholder: 'Enter faculty name' },
            { label: 'Department', value: facDept, setter: setFacDept, placeholder: 'Enter department' },
            { label: 'Designation', value: facDesg, setter: setFacDesg, placeholder: 'Enter designation' },
            { label: 'Attendance', value: facAtt, setter: setFacAtt, placeholder: 'Enter attendance (e.g., 100%)' },
            { label: 'Phone', value: facPh, setter: setFacPh, placeholder: 'Enter phone number', keyboardType: 'phone-pad' },
            { label: 'Email', value: facEmail, setter: setFacEmail, placeholder: 'Enter email', keyboardType: 'email-address' },
          ].map(({ label, value, setter, placeholder, keyboardType }, idx) => (
            <View key={idx} style={styles.inputGroup}>
              <Text style={styles.label}>{label}</Text>
              <TextInput
                value={value}
                onChangeText={setter}
                placeholder={placeholder}
                style={styles.input}
                keyboardType={keyboardType || 'default'}
                autoCapitalize="none"
                editable={!updating}
              />
            </View>
          ))}

          <TouchableOpacity
            onPress={handleUpdate}
            style={[styles.button, updating && { backgroundColor: '#7588c9' }]}
            disabled={updating}
          >
            <Text style={styles.buttonText}>{updating ? 'Updating...' : 'Update Faculty'}</Text>
          </TouchableOpacity>
        </>
      )}

      <TouchableOpacity onPress={() => navigation.goBack()} style={[styles.button, styles.backButton]}>
        <Text style={[styles.buttonText, styles.backButtonText]}>Go Back</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    paddingBottom: 40,
    backgroundColor: '#f4f6f7',
    flexGrow: 1,
  },
  heading: {
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 20,
    color: '#34495e',
    textAlign: 'center',
  },
  inputGroup: {
    marginBottom: 15,
  },
  label: {
    fontWeight: '600',
    marginBottom: 6,
    fontSize: 16,
    color: '#2d3436',
  },
  input: {
    borderWidth: 1,
    borderColor: '#dcdde1',
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 8,
    fontSize: 16,
    color: '#2f3640',
  },
  button: {
    backgroundColor: '#4a69bd',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 20,
    shadowColor: '#2c3e50',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  buttonText: {
    color: '#f1f2f6',
    fontWeight: '700',
    fontSize: 18,
  },
  backButton: {
    backgroundColor: '#95a5a6',
    marginTop: 12,
  },
  backButtonText: {
    color: '#2f3640',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
});

export default EditFaculty;
