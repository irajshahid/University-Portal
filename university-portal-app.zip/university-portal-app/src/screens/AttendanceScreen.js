import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useSelector } from 'react-redux';
import { AntDesign } from '@expo/vector-icons';

export default function AttendanceScreen({ navigation }) {
  const currentUser = useSelector(state => state.user.currentUser);
  const sheetData = useSelector(state => state.portal.sheetData);


  const attendanceRecord = sheetData.find(row =>
    (row.email || row.Email || '').toLowerCase() === (currentUser?.email || '').toLowerCase()
  );

  return (
    <View style={styles.container}>
   
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <AntDesign name="arrowleft" size={24} color="#0a3d62" />
        <Text style={styles.backText}>Go Back</Text>
      </TouchableOpacity>

      {attendanceRecord && attendanceRecord.studentatt ? (
        <View style={styles.card}>
          <Text style={styles.attendanceText}>
            Your attendance: {attendanceRecord.studentatt}
          </Text>
        </View>
      ) : (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No attendance data available for your account</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f6fb',
    padding: 20,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    paddingVertical: 6,
    paddingHorizontal: 10,
    backgroundColor: '#d6e0f0',
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  backText: {
    fontSize: 16,
    color: '#0a3d62',
    marginLeft: 8,
    fontWeight: '600',
  },
  card: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  attendanceText: {
    fontSize: 16,
    color: '#333',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 18,
    color: '#888',
    fontStyle: 'italic',
  },
});
