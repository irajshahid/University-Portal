import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useSelector } from 'react-redux';
import { AntDesign } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

const FeeStatusScreen = () => {
  const navigation = useNavigation();
  const currentUser = useSelector(state => state.user.currentUser);
  const sheetData = useSelector(state => state.portal.sheetData);

  console.log("Current User Email:", currentUser?.email);
  console.log("Sheet Data:", sheetData);
  console.log("Checking match with:", sheetData.map(row => row.email || row.Email || row['Email Address']));

  const feeRecord = sheetData.find(row => {
    const emailValue = row.email || row.Email || row['Email Address'] || '';
    return emailValue.toLowerCase() === (currentUser?.email || '').toLowerCase();
  });

  console.log("Matched Fee Record:", feeRecord);

  return (
    <View style={styles.container}>
    
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <AntDesign name="arrowleft" size={24} color="#0a3d62" />
        <Text style={styles.backText}>Go Back</Text>
      </TouchableOpacity>

      {feeRecord && feeRecord.feestatus ? (
        <View style={styles.card}>
          <Text style={styles.feeText}>
            Your Fee Status: {feeRecord.feestatus.charAt(0).toUpperCase() + feeRecord.feestatus.slice(1)}
          </Text>
        </View>
      ) : (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No invoice records found for your account</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f6fb',
    padding: 20,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    paddingVertical: 6,
    paddingHorizontal: 10,
    backgroundColor: '#d6e0f0',
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  backText: {
    fontSize: 16,
    color: '#0a3d62',
    marginLeft: 8,
    fontWeight: '600',
  },
  card: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  feeText: {
    fontSize: 16,
    color: '#333',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 18,
    color: '#888',
    fontStyle: 'italic',
  },
});

export default FeeStatusScreen;
