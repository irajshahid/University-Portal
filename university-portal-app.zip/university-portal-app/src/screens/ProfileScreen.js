// screens/ProfileScreen.js
import React, { useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { fetchSheetData } from '../feature/PortalSlice';
import { AntDesign } from '@expo/vector-icons';

const ProfileScreen = ({ navigation }) => {
  const dispatch = useDispatch();

  const sheetData = useSelector((state) => state.portal.sheetData);
  const loading = useSelector((state) => state.portal.loading);
  const error = useSelector((state) => state.portal.error);

 
  const currentUser = useSelector((state) => state.user?.currentUser);

  useEffect(() => {
    dispatch(fetchSheetData());
  }, [dispatch]);

  if (!currentUser?.email || !currentUser?.password) {
    return (
      <View style={styles.centered}>
        <Text>User not logged in or missing credentials.</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.centered}>
        <Text style={styles.error}>Error: {error}</Text>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={styles.centered}>
        <Text>Loading...</Text>
      </View>
    );
  }

  const validSheetData = Array.isArray(sheetData) ? sheetData : [];

  const cleanedEmail = currentUser.email.trim().toLowerCase();
  const cleanedPassword = currentUser.password.trim();

  // Find the student jahan email AND password match
  const student = validSheetData.find(
    (row) =>
      row.email?.trim().toLowerCase() === cleanedEmail &&
      row.password?.trim() === cleanedPassword
  );

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <AntDesign name="arrowleft" size={24} color="#0a3d62" />
        <Text style={styles.backText}>Go Back</Text>
      </TouchableOpacity>

      {student ? (
        <View style={styles.card}>
          <Text style={styles.name}>{student.stdname}</Text>
          <Text>Email: {student.email}</Text>
          <Text>DOB: {student.dob}</Text>
          <Text>Degree: {student.degree}</Text>
          <Text>Fee Status: {student.feestatus}</Text>
          <Text>Semester: {student.semester}</Text>
          <Text>CGPA: {student.cgpa}</Text>
          <Text>GPA: {student.gpa}</Text>
          <Text>Role: {student.role}</Text>
          <Text>Student ID: {student.stdid}</Text>
        </View>
      ) : (
        <Text>No data found for this student with the provided credentials.</Text>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { padding: 16 },
  backButton: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  backText: { fontSize: 16, color: '#0a3d62', marginLeft: 8 },
  card: { marginBottom: 20, padding: 16, backgroundColor: '#f0f0f0', borderRadius: 8 },
  name: { fontWeight: 'bold', fontSize: 18, marginBottom: 4 },
  error: { color: 'red' },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
});

export default ProfileScreen;
