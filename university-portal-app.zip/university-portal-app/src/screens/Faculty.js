import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');
const cardSize = (width - 60) / 2;

export default function FacultyOptionsScreen({ navigation }) {
  return (
    <View style={styles.container}>
     
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Ionicons name="arrow-back" size={24} color="#1e3799" />
        <Text style={styles.backText}>Back</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Faculty Management</Text>

      <View style={styles.grid}>
        <TouchableOpacity
          style={styles.card}
          onPress={() => navigation.navigate('AddFac')}
          activeOpacity={0.7}
        >
          <Ionicons name="person-add" size={40} color="#f1f2f6" />
          <Text style={styles.cardText}>Add Faculty</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.card}
          onPress={() => navigation.navigate('DelFac')}
          activeOpacity={0.7}
        >
          <MaterialIcons name="delete" size={40} color="#f1f2f6" />
          <Text style={styles.cardText}>Delete Faculty</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.card}
          onPress={() => navigation.navigate('FacultyInfo')}
          activeOpacity={0.7}
        >
          <MaterialIcons name="info" size={40} color="#f1f2f6" />
          <Text style={styles.cardText}>Display Info</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.card}
          onPress={() => navigation.navigate('Editfac')}
          activeOpacity={0.7}
        >
          <MaterialIcons name="edit" size={40} color="#f1f2f6" />
          <Text style={styles.cardText}>Edit Faculty</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f6f7',
    padding: 20,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  backText: {
    marginLeft: 6,
    fontSize: 16,
    color: '#1e3799',
    fontWeight: '600',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#0a3d62',
    textAlign: 'center',
    marginBottom: 30,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  card: {
    width: cardSize,
    height: cardSize * 0.8,
    backgroundColor: '#4a69bd',
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#1e3799',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  cardText: {
    fontSize: 18,
    color: '#f1f2f6',
    fontWeight: '600',
    textAlign: 'center',
    marginTop: 10,
  },
});
