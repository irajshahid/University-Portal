import React, { useState } from 'react';
import {
  View,
  TextInput,
  Text,
  Alert,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function AddStudent({ navigation }) {
  const [form, setForm] = useState({
    id: '',
    name: '',
    dob: '',
    program: '',
    feeStatus: '',
  });

  const handleChange = (key, value) => {
    setForm({ ...form, [key]: value });
  };

  const handleSubmit = async () => {
    const endpoint =
      'https://api.sheetbest.com/sheets/560bd63f-eade-4c48-96da-452c0495857e';

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          stdid: form.id,
          stdname: form.name,
          dob: form.dob,
          degree: form.program,
          feestatus: form.feeStatus,
        }),
      });

      if (response.ok) {
        Alert.alert('Success', 'Student added successfully');
      
      } else {
        Alert.alert('Error', 'Failed to add student');
      }
    } catch (error) {
      Alert.alert('Error', 'Network error');
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
   
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Ionicons name="arrow-back" size={24} color="#1e3799" />
        <Text style={styles.backButtonText}>Go Back</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Add Student</Text>

      <View style={styles.form}>
        {[
          { key: 'id', label: 'Student ID' },
          { key: 'name', label: 'Full Name' },
          { key: 'dob', label: 'Date of Birth (YYYY-MM-DD)' },
          { key: 'program', label: 'Degree Program' },
        ].map(({ key, label }) => (
          <TextInput
            key={key}
            placeholder={label}
            value={form[key]}
            onChangeText={(text) => handleChange(key, text)}
            style={styles.input}
            placeholderTextColor="#666"
          />
        ))}

  
        <Text style={styles.radioLabel}>Fee Status:</Text>
        <View style={styles.radioContainer}>
          {['Paid', 'Unpaid'].map((status) => (
            <TouchableOpacity
              key={status}
              style={styles.radioOption}
              onPress={() => handleChange('feeStatus', status)}
            >
              <View
                style={[
                  styles.radioCircle,
                  form.feeStatus === status && styles.selected,
                ]}
              />
              <Text style={styles.radioText}>{status}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity style={styles.button} onPress={handleSubmit}>
          <Text style={styles.buttonText}>Add Student</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 24,
    backgroundColor: '#f2f4f7',
    flexGrow: 1,
    justifyContent: 'center',
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  backButtonText: {
    marginLeft: 6,
    fontSize: 16,
    color: '#1e3799',
    fontWeight: '600',
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    textAlign: 'center',
    color: '#1e3799',
    marginBottom: 24,
  },
  form: {
    backgroundColor: '#ffffff',
    padding: 20,
    borderRadius: 16,
    elevation: 6,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
  },
  input: {
    borderWidth: 1,
    borderColor: '#ced6e0',
    borderRadius: 12,
    padding: 12,
    fontSize: 16,
    marginBottom: 16,
    backgroundColor: '#f8f9fa',
  },
  radioLabel: {
    fontSize: 16,
    marginBottom: 8,
    fontWeight: '600',
    color: '#34495e',
  },
  radioContainer: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  radioOption: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 20,
  },
  radioCircle: {
    height: 18,
    width: 18,
    borderRadius: 9,
    borderWidth: 2,
    borderColor: '#1e3799',
    marginRight: 8,
  },
  selected: {
    backgroundColor: '#1e3799',
  },
  radioText: {
    fontSize: 16,
    color: '#34495e',
  },
  button: {
    backgroundColor: '#4a69bd',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 10,
  },
  buttonText: {
    color: '#f1f2f6',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
