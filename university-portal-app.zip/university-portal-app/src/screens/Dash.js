
import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Dimensions,
} from 'react-native';
import {
  MaterialIcons,
  FontAwesome5,
  Ionicons,
  Feather,
  Entypo,
} from '@expo/vector-icons';

import { useSelector } from 'react-redux'; 

const buttons = [
  {
    title: 'My Profile',
    screen: 'ProfileScreen',
    icon: <MaterialIcons name="person" size={40} color="#f1f2f6" />,
  },
  {
    title: 'My Courses',
    screen: 'CoursesScreen',
    icon: <FontAwesome5 name="book" size={40} color="#f1f2f6" />,
  },
  {
    title: 'Attendance',
    screen: 'AttendanceScreen',
    icon: <Ionicons name="document-text" size={40} color="#f1f2f6" />,
  },
  {
    title: 'Notifications',
    screen: 'notificationScreen',
    icon: <Ionicons name="notifications" size={40} color="#f1f2f6" />,
  },
  {
    title: 'Invoice',
    screen: 'InvoicesScreen',
    icon: <FontAwesome5 name="file-invoice" size={40} color="#f1f2f6" />,
  },
];

const { width } = Dimensions.get('window');
const cardSize = (width - 60) / 2;

export default function StudentDashboardScreen({ navigation }) {
  const user = useSelector((state) => state.user.currentUser);

  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>
          Welcome, {user?.stdname || user?.name || user?.email || 'Student'}
        </Text>

        <View style={styles.grid}>
          {buttons.map(({ title, screen, icon }) => (
            <TouchableOpacity
              key={screen}
              style={styles.card}
              onPress={() => navigation.navigate(screen)}
              activeOpacity={0.7}
            >
              {icon}
              <Text style={styles.cardText}>{title}</Text>
            </TouchableOpacity>
          ))}

          <TouchableOpacity
            style={[styles.card, styles.logoutCard]}
            onPress={() => navigation.replace('Login')}
            activeOpacity={0.7}
          >
            <MaterialIcons name="logout" size={40} color="#f1f2f6" />
            <Text style={[styles.cardText, styles.logoutText]}>Logout</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Bottom Navigation Bar */}
      <View style={styles.navbar}>
        <TouchableOpacity onPress={() => navigation.navigate('Dash')}>
          <Feather name="home" size={28} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('notificationScreen')}>
          <Ionicons name="notifications-outline" size={28} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('ProfileScreen')}>
          <Entypo name="user" size={28} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  container: {
    paddingVertical: 40,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 26,
    fontWeight: '700',
    marginBottom: 20,
    color: '#0a3d62',
    textAlign: 'center',
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  card: {
    width: cardSize,
    height: cardSize,
    backgroundColor: '#4a69bd',
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#1e3799',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  cardText: {
    fontSize: 18,
    color: '#f1f2f6',
    fontWeight: '600',
    textAlign: 'center',
    marginTop: 10,
  },
  logoutCard: {
    backgroundColor: '#eb3b5a',
  },
  logoutText: {
    fontWeight: '700',
  },
  navbar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#3c6382',
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: '#ced6e0',
  },
});
