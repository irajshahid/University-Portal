import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
} from 'react-native';
import { Ionicons, MaterialIcons } from '@expo/vector-icons';

export default function ProfileScreen({ navigation }) {
  const admin = {
    name: 'Admin User',
    email: 'admin@university.edu',
    password: '********',
    role: 'Administrator',
  };

  return (
    <SafeAreaView style={styles.container}>
    
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
        <Ionicons name="arrow-back" size={28} color="#4a69bd" />
        <Text style={styles.backText}>Back</Text>
      </TouchableOpacity>

      <View style={styles.header}>
        <Ionicons name="person-circle-outline" size={100} color="#4a69bd" />
        <Text style={styles.name}>{admin.name}</Text>
        <Text style={styles.role}>{admin.role}</Text>
      </View>

      <View style={styles.infoContainer}>
        <View style={styles.infoItem}>
          <MaterialIcons name="email" size={24} color="#4a69bd" />
          <Text style={styles.label}>Email</Text>
          <Text style={styles.value}>{admin.email}</Text>
        </View>

        <View style={styles.infoItem}>
          <MaterialIcons name="lock" size={24} color="#4a69bd" />
          <Text style={styles.label}>Password</Text>
          <Text style={styles.value}>{admin.password}</Text>
        </View>

        <View style={styles.infoItem}>
          <MaterialIcons name="admin-panel-settings" size={24} color="#4a69bd" />
          <Text style={styles.label}>Role</Text>
          <Text style={styles.value}>{admin.role}</Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
    paddingHorizontal: 20,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 20,
  },
  backText: {
    marginLeft: 6,
    fontSize: 16,
    color: '#4a69bd',
    fontWeight: '600',
  },
  header: {
    alignItems: 'center',
    marginVertical: 30,
  },
  name: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1e272e',
    marginTop: 10,
  },
  role: {
    fontSize: 16,
    color: '#4a69bd',
    fontWeight: '600',
  },
  infoContainer: {
    marginTop: 20,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  infoItem: {
    marginBottom: 20,
  },
  label: {
    fontSize: 14,
    color: '#576574',
    marginTop: 4,
  },
  value: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e272e',
  },
});
