import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function CourseInfo({ navigation }) {
  const [courses, setCourses] = useState([]);
  const [filteredCourses, setFilteredCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const endpoint = 'https://api.sheetbest.com/sheets/560bd63f-eade-4c48-96da-452c0495857e';

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const res = await fetch(endpoint);
        const data = await res.json();
        setCourses(data);
        setFilteredCourses(data);
      } catch (err) {
        alert('Failed to fetch courses');
      }
      setLoading(false);
    };

    fetchCourses();
  }, []);

  const handleSearch = (text) => {
    setSearchTerm(text);
    if (text.trim() === '') {
      setFilteredCourses(courses);
      return;
    }

    const filtered = courses.filter(
      (c) =>
        c.coursecode?.toLowerCase().includes(text.toLowerCase()) ||
        c.coursetitle?.toLowerCase().includes(text.toLowerCase())
    );
    setFilteredCourses(filtered);
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Ionicons name="arrow-back" size={24} color="#1e3799" />
        <Text style={styles.backText}>Back</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Course Info</Text>

      <TextInput
        style={styles.searchInput}
        placeholder="Search by Code or Title"
        value={searchTerm}
        onChangeText={handleSearch}
      />

      {loading ? (
        <ActivityIndicator size="large" color="#1e3799" style={{ marginTop: 20 }} />
      ) : filteredCourses.length === 0 ? (
        <Text style={styles.noDataText}>No courses found.</Text>
      ) : (
        filteredCourses.map((course, index) => (
          <View key={index} style={styles.card}>
            <Text style={styles.label}>
              Code: <Text style={styles.value}>{course.coursecode}</Text>
            </Text>
            <Text style={styles.label}>
              Title: <Text style={styles.value}>{course.coursetitle}</Text>
            </Text>
          </View>
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#f4f6f7',
    padding: 20,
    flexGrow: 1,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  backText: {
    marginLeft: 6,
    fontSize: 16,
    color: '#1e3799',
    fontWeight: '600',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0a3d62',
    textAlign: 'center',
    marginBottom: 20,
  },
  searchInput: {
    backgroundColor: '#fff',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#dcdde1',
  },
  card: {
    backgroundColor: '#dff9fb',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    elevation: 4,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#130f40',
    marginBottom: 4,
  },
  value: {
    fontWeight: '400',
    color: '#30336b',
  },
  noDataText: {
    textAlign: 'center',
    fontSize: 16,
    color: '#636e72',
    marginTop: 30,
  },
});
