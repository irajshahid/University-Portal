import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Dimensions,
} from 'react-native';
import {
  MaterialIcons,
  FontAwesome5,
  Ionicons,
  Feather,
  Entypo,
} from '@expo/vector-icons';

const buttons = [
  { title: 'Students', screen: 'Students', icon: <MaterialIcons name="people" size={40} color="#fff" /> },
  { title: 'Courses', screen: 'Course', icon: <FontAwesome5 name="book-open" size={40} color="#fff" /> },
  { title: 'Faculty', screen: 'Faculty', icon: <MaterialIcons name="event-available" size={40} color="#fff" /> },
  { title: 'Notifications', screen: 'Notf', icon: <Ionicons name="notifications" size={40} color="#fff" /> },
  { title: 'Requests', screen: 'Feature', icon: <Ionicons name="person-circle" size={40} color="#fff" /> },
];

const { width } = Dimensions.get('window');
const cardSize = (width - 60) / 2;

export default function DashboardScreen({ navigation }) {
  const [activeNav, setActiveNav] = useState('Dashboard');

  const handleNavPress = (screen) => {
    setActiveNav(screen);
    navigation.navigate(screen);
  };

  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>Welcome!</Text>

        <View style={styles.grid}>
          {buttons.map(({ title, screen, icon }) => (
            <TouchableOpacity
              key={screen}
              style={styles.card}
              onPress={() => navigation.navigate(screen)}
              activeOpacity={0.85}
            >
              {icon}
              <Text style={styles.cardText}>{title}</Text>
            </TouchableOpacity>
          ))}

          <TouchableOpacity
            style={[styles.card, styles.logoutCard]}
            onPress={() => navigation.replace('Login')}
            activeOpacity={0.85}
          >
            <MaterialIcons name="logout" size={40} color="#fff" />
            <Text style={[styles.cardText, styles.logoutText]}>Logout</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      <View style={styles.navbar}>
        <TouchableOpacity onPress={() => handleNavPress('Dashboard')} style={styles.navItem}>
          <Feather
            name="home"
            size={28}
            color={activeNav === 'Dashboard' ? '#f39c12' : '#f1f2f6'}
          />
          <Text style={[styles.navText, activeNav === 'Dashboard' && styles.navTextActive]}>Home</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => handleNavPress('Notf')} style={styles.navItem}>
          <Ionicons
            name="notifications-outline"
            size={28}
            color={activeNav === 'Notf' ? '#f39c12' : '#f1f2f6'}
          />
          <Text style={[styles.navText, activeNav === 'Notf' && styles.navTextActive]}>Notifications</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => handleNavPress('Adminprof')} style={styles.navItem}>
          <Entypo
            name="user"
            size={28}
            color={activeNav === 'Profile' ? '#f39c12' : '#f1f2f6'}
          />
          <Text style={[styles.navText, activeNav === 'Profile' && styles.navTextActive]}>Profile</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#f8fafc', 
  },
  container: {
    paddingVertical: 40,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 26,
    fontWeight: '700',
    marginBottom: 30,
    color: '#0a3d62',  
    textAlign: 'center',
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    width: '100%',
  },
  card: {
    width: cardSize,
    height: cardSize,
    backgroundColor: '#4a69bd', 
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    padding: 12,

    shadowColor: '#1e3799',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 7,
  },
  cardText: {
    fontSize: 18,
    color: '#f1f2f6',
    fontWeight: '600',
    textAlign: 'center',
    marginTop: 10,
  },
  logoutCard: {
    backgroundColor: '#eb3b5a', 
  },
  logoutText: {
    fontWeight: '700',
  },
 navbar: {
  flexDirection: 'row',
  justifyContent: 'space-around',
  backgroundColor: '#4a69bd', 
  paddingVertical: 14,
  borderTopWidth: 1,
  borderTopColor: '#ced6e0',
},

  navItem: {
    alignItems: 'center',
  },
  navText: {
    color: '#f1f2f6',  
    fontSize: 12,
    marginTop: 4,
  },
  navTextActive: {
    color: '#f39c12', 
    fontWeight: '700',
  },
});
