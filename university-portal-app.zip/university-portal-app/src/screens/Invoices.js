import React from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { useSelector } from 'react-redux';
import { AntDesign } from '@expo/vector-icons';

export default function InvoiceScreen({ navigation }) {

  const invoices = useSelector(state =>
    (state.portal?.data ?? []).filter(row => row.type === 'invoice')
  );

  return (
    <ScrollView contentContainerStyle={styles.container}>
    
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <AntDesign name="arrowleft" size={24} color="#0a3d62" />
        <Text style={styles.backText}>Go Back</Text>
      </TouchableOpacity>

      <Text style={styles.heading}>Invoices</Text>

      {invoices.length === 0 ? (
        <Text>No invoice records found</Text>
      ) : (
        invoices.map((invoice, index) => (
          <View key={index} style={styles.card}>
            <Text style={styles.label}>Semester: <Text style={styles.value}>{invoice.semester}</Text></Text>
            <Text style={styles.label}>Amount: <Text style={styles.value}>PKR {invoice.amount}</Text></Text>
            <Text style={styles.label}>Due Date: <Text style={styles.value}>{invoice.dueDate}</Text></Text>
            <Text
              style={[
                styles.status,
                invoice.status?.toLowerCase() === 'paid'
                  ? styles.paid
                  : styles.unpaid,
              ]}
            >
              {invoice.status?.toUpperCase()}
            </Text>
          </View>
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    paddingBottom: 60,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  backText: {
    fontSize: 16,
    color: '#0a3d62',
    marginLeft: 8,
  },
  heading: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 12,
    color: '#1e272e',
  },
  card: {
    backgroundColor: '#dff9fb',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  label: {
    fontWeight: '600',
    fontSize: 15,
    marginBottom: 4,
    color: '#2f3542',
  },
  value: {
    fontWeight: 'normal',
    color: '#3742fa',
  },
  status: {
    marginTop: 10,
    fontWeight: 'bold',
    textAlign: 'right',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 8,
    alignSelf: 'flex-end',
  },
  paid: {
    backgroundColor: '#2ed573',
    color: '#fff',
  },
  unpaid: {
    backgroundColor: '#ff4757',
    color: '#fff',
  },
});
