import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ActivityIndicator,
} from 'react-native';

export default function DeleteCourse({ navigation }) {
  const [coursecode, setCoursecode] = useState('');
  const [loading, setLoading] = useState(false);

  const endpoint = 'https://api.sheetbest.com/sheets/560bd63f-eade-4c48-96da-452c0495857e';

  const handleDeleteCourse = async () => {
    if (!coursecode.trim()) {
      Alert.alert('Error', 'Please enter a valid Course Code');
      return;
    }

    setLoading(true);
    try {
      
      const response = await fetch(endpoint);
      if (!response.ok) {
        Alert.alert('Error', 'Failed to fetch courses');
        setLoading(false);
        return;
      }

      const data = await response.json();

   
      const rowIndex = data.findIndex(
        (course) =>
          course.coursecode &&
          course.coursecode.trim().toLowerCase() === coursecode.trim().toLowerCase()
      );

      if (rowIndex === -1) {
        Alert.alert('Not Found', `Course code "${coursecode}" not found`);
        setLoading(false);
        return;
      }

      const deleteUrl = `${endpoint}/${rowIndex}`;
      const deleteResponse = await fetch(deleteUrl, { method: 'DELETE' });

      if (deleteResponse.ok) {
        Alert.alert('Success', `Course code "${coursecode}" deleted successfully`);
        setCoursecode('');
      } else {
        const errorText = await deleteResponse.text();
        Alert.alert('Delete Failed', errorText);
      }
    } catch (error) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Delete Course</Text>

      <TextInput
        style={styles.input}
        placeholder="Enter Course Code to Delete"
        value={coursecode}
        onChangeText={setCoursecode}
        autoCapitalize="characters"
        editable={!loading}
        onSubmitEditing={handleDeleteCourse}
      />

      <TouchableOpacity
        style={[styles.button, loading && { backgroundColor: '#b33939' }]}
        onPress={handleDeleteCourse}
        disabled={loading}
      >
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Delete</Text>}
      </TouchableOpacity>

      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Text style={styles.backText}>Go Back</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f4f6f7' },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#0a3d62',
    textAlign: 'center',
  },
  input: {
    backgroundColor: '#fff',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 12,
    marginBottom: 20,
    fontSize: 16,
  },
  button: {
    backgroundColor: '#e74c3c',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 17,
    fontWeight: 'bold',
  },
  backButton: {
    marginTop: 15,
    alignItems: 'center',
  },
  backText: {
    fontSize: 16,
    color: '#1e3799',
    fontWeight: '500',
  },
});

