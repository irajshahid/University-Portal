import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  ActivityIndicator,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function DisplayStudent({ navigation }) {
  const [students, setStudents] = useState([]);
  const [filteredStudents, setFilteredStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const endpoint = 'https://api.sheetbest.com/sheets/560bd63f-eade-4c48-96da-452c0495857e';
   
  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const response = await fetch(endpoint);
        const data = await response.json();
        setStudents(data);
        setFilteredStudents(data);
      } catch (error) {
        alert('Failed to fetch student data');
      }
      setLoading(false);
    };

    fetchStudents();
  }, []);

  const handleSearch = (text) => {
    setSearchTerm(text);

    if (text.trim() === '') {
      setFilteredStudents(students);
      return;
    }

    const filtered = students.filter(
      (student) =>
        student.stdid.toLowerCase().includes(text.toLowerCase()) ||
        student.stdname.toLowerCase().includes(text.toLowerCase())
    );
    setFilteredStudents(filtered);
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Ionicons name="arrow-back" size={24} color="#1e3799" />
        <Text style={styles.backButtonText}>Back</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Student Info</Text>

      <TextInput
        style={styles.searchInput}
        placeholder="Search by ID or Name"
        value={searchTerm}
        onChangeText={handleSearch}
        autoCorrect={false}
        autoCapitalize="none"
        clearButtonMode="while-editing"
      />

      {loading ? (
        <ActivityIndicator size="large" color="#1e3799" style={{ marginTop: 20 }} />
      ) : filteredStudents.length === 0 ? (
        <Text style={styles.noResultsText}>No students found.</Text>
      ) : (
        filteredStudents.map((student, index) => (
          <View key={index} style={styles.card}>
            <Text style={styles.label}>
              ID: <Text style={styles.value}>{student.stdid}</Text>
            </Text>
            <Text style={styles.label}>
              Name: <Text style={styles.value}>{student.stdname}</Text>
            </Text>
            <Text style={styles.label}>
              DOB: <Text style={styles.value}>{student.dob}</Text>
            </Text>
            <Text style={styles.label}>
              Degree: <Text style={styles.value}>{student.degree}</Text>
            </Text>
            <Text style={styles.label}>
              Fee Status: <Text style={styles.value}>{student.feestatus}</Text>
            </Text>
            <Text style={styles.label}>
              Semester: <Text style={styles.value}>{student.semester}</Text>
            </Text>
            <Text style={styles.label}>
              GPA: <Text style={styles.value}>{student.gpa}</Text>
            </Text>
            <Text style={styles.label}>
              CGPA: <Text style={styles.value}>{student.cgpa}</Text>
            </Text>
          </View>
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#f2f4f7',
    flexGrow: 1,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  backButtonText: {
    marginLeft: 6,
    fontSize: 16,
    color: '#1e3799',
    fontWeight: '600',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#0a3d62',
    textAlign: 'center',
    marginBottom: 20,
  },
  searchInput: {
    backgroundColor: '#fff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#ced6e0',
  },
  noResultsText: {
    textAlign: 'center',
    color: '#8395a7',
    fontSize: 16,
    marginTop: 30,
  },
  card: {
    backgroundColor: '#dff9fb',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    elevation: 4,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#130f40',
    marginBottom: 4,
  },
  value: {
    fontWeight: '400',
    color: '#30336b',
  },
});
