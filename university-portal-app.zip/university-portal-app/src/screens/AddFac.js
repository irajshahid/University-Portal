import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function AddFaculty({ navigation }) {
  const [FacId, setFacId] = useState('');
  const [FacName, setFacName] = useState('');
  const [FacDept, setFacDept] = useState('');
  const [FacEmail, setFacEmail] = useState('');
  const [FacPh, setFacPh] = useState('');
  const [FacDesg, setFacDesg] = useState('');

  const endpoint = 'https://api.sheetbest.com/sheets/560bd63f-eade-4c48-96da-452c0495857e'; 

  const handleAddFaculty = async () => {
    if (!FacId || !FacName || !FacDept) {
      Alert.alert('Error', 'Please fill all required fields');
      return;
    }

    const newFaculty = {
    FacId,
    FacName,
    FacDept,
    FacDesg,
    FacAtt: '',
    FacPh,
    FacEmail,
    };

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newFaculty),
      });

      if (response.ok) {
        Alert.alert('Success', 'Faculty added successfully');
     
        setFacId('');
        setFacName('');
        setFacDept('');
        setFacEmail('');
        setFacPh('');
        setFacDesg('');
        navigation.goBack();
      } else {
        Alert.alert('Error', 'Failed to add faculty');
      }
    } catch (error) {
      Alert.alert('Error', 'Network error while adding faculty');
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
  
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Ionicons name="arrow-back" size={24} color="#1e3799" />
        <Text style={styles.backButtonText}>Back</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Add Faculty</Text>

      <TextInput
        placeholder="Faculty ID *"
        style={styles.input}
        value={FacId}
        onChangeText={setFacId}
      />
      <TextInput
        placeholder="Faculty Name *"
        style={styles.input}
        value={FacName}
        onChangeText={setFacName}
      />
      <TextInput
        placeholder="Department *"
        style={styles.input}
        value={FacDept}
        onChangeText={setFacDept}
      />
      <TextInput
        placeholder="Email"
        style={styles.input}
        value={FacEmail}
        onChangeText={setFacEmail}
        keyboardType="email-address"
      />
      <TextInput
        placeholder="Phone"
        style={styles.input}
        value={FacPh}
        onChangeText={setFacPh}
        keyboardType="phone-pad"
      />
      <TextInput
        placeholder="Designation"
        style={styles.input}
        value={FacDesg}
        onChangeText={setFacDesg}
      />

      <TouchableOpacity style={styles.button} onPress={handleAddFaculty}>
        <Text style={styles.buttonText}>Add Faculty</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#f2f4f7',
    flexGrow: 1,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  backButtonText: {
    marginLeft: 6,
    fontSize: 16,
    color: '#1e3799',
    fontWeight: '600',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#0a3d62',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 12,
    marginBottom: 15,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#ced6e0',
  },
  button: {
    backgroundColor: '#4a69bd',
    paddingVertical: 15,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 10,
    elevation: 4,
  },
  buttonText: {
    color: '#f1f2f6',
    fontWeight: '600',
    fontSize: 18,
  },
});
