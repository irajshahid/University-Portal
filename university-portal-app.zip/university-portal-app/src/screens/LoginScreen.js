// src/screens/LoginScreen.js
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  useWindowDimensions,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useDispatch } from 'react-redux';
import { login } from '../feature/UserSlice';  

export default function LoginScreen({ navigation }) {
  const { width } = useWindowDimensions();
  const dispatch = useDispatch();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const SHEET_BEST_URL =
    'https://api.sheetbest.com/sheets/560bd63f-eade-4c48-96da-452c0495857e';

  const handleLogin = async (role) => {
    
    if (!email.trim() || !password.trim()) {
      alert('Please enter both email and password');
      return;
    }

    try {
     
      const response = await fetch(SHEET_BEST_URL);
      if (!response.ok) {
        alert('Failed to fetch user data. Please try again later.');
        return;
      }
      const data = await response.json();

      const user = data.find((item) => {
        const userEmail = (item.email || item.Email || '').trim().toLowerCase();
        const userPass  = (item.password || item.Password || '').trim();
        const userRole  = (item.role || item.Role || '').trim().toLowerCase();

        return (
          userEmail === email.trim().toLowerCase() &&
          userPass  === password.trim() &&
          userRole  === role.toLowerCase()
        );
      });

      if (!user) {
        alert(`Invalid credentials or not authorized as ${role}`);
        return;
      }
      dispatch(login(user));

      
      if (role.toLowerCase() === 'student') {
        navigation.replace('Student'); 
      } else {
        navigation.replace('Admin');    
      }
    } catch (error) {
      console.error('Login error:', error);
      alert('Login failed, please try again later');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#F9F9F9" />
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.inner}
      >
        <Text style={styles.title}>Sign in to Portal</Text>

        <TextInput
          placeholder="Email"
          placeholderTextColor="#888"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          style={styles.input}
        />

        <TextInput
          placeholder="Password"
          placeholderTextColor="#888"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          style={styles.input}
        />

        <TouchableOpacity onPress={() => alert('Forgot password clicked')}>
          <Text style={styles.forgotText}>Forgot your password?</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.buttonStudent}
          onPress={() => handleLogin('student')}
        >
          <Text style={styles.buttonText}>Login as Student</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.buttonAdmin}
          onPress={() => handleLogin('admin')}
        >
          <Text style={styles.buttonTextAlt}>Login as Admin</Text>
        </TouchableOpacity>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9F9F9',
    paddingHorizontal: 20,
  },
  inner: {
    flex: 1,
    justifyContent: 'center',
    maxWidth: 400,
    alignSelf: 'center',
    width: '100%',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#159A88',
    textAlign: 'center',
    marginBottom: 30,
  },
  input: {
    backgroundColor: '#F2F2F2',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 10,
    fontSize: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#ddd',
    color: '#333',
  },
  forgotText: {
    color: '#159A88',
    textAlign: 'right',
    marginBottom: 24,
    fontSize: 14,
  },
  buttonStudent: {
    backgroundColor: '#20C997',
    paddingVertical: 14,
    borderRadius: 10,
    marginBottom: 12,
  },
  buttonAdmin: {
    backgroundColor: '#36CFC9',
    paddingVertical: 14,
    borderRadius: 10,
  },
  buttonText: {
    color: '#fff',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 16,
  },
  buttonTextAlt: {
    color: '#fff',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 16,
  },
});
