import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ActivityIndicator,
  ScrollView,
} from 'react-native';

const SHEETBEST_BASE_URL = 'https://api.sheetbest.com/sheets/560bd63f-eade-4c48-96da-452c0495857e';

const Editstudent = ({ route, navigation }) => {

  const routeStdid = route?.params?.stdid || '';
  const [stdid, setStdid] = useState(routeStdid);

  const [loading, setLoading] = useState(false); 
  const [updating, setUpdating] = useState(false);

  const [stdname, setStdname] = useState('');
  const [dob, setDob] = useState('');
  const [degree, setDegree] = useState('');
  const [feestatus, setFeestatus] = useState('');
  const [semester, setSemester] = useState('');
  const [cgpa, setCgpa] = useState('');
  const [gpa, setGpa] = useState('');

  const [studentLoaded, setStudentLoaded] = useState(false);

 
  const fetchStudent = async () => {
    if (!stdid) {
      Alert.alert('Input Error', 'Please enter a student ID.');
      return;
    }

    try {
      setLoading(true);
      setStudentLoaded(false);

      const response = await fetch(`${SHEETBEST_BASE_URL}?stdid=${stdid}`);
      const data = await response.json();

      if (data.length === 0) {
        Alert.alert('Not found', `Student with ID ${stdid} not found.`);
        return;
      }

      const student = data[0];
      setStdname(student.stdname || '');
      setDob(student.dob || '');
      setDegree(student.degree || '');
      setFeestatus(student.feestatus || '');
      setSemester(student.semester ? student.semester.toString() : '');
      setCgpa(student.cgpa ? student.cgpa.toString() : '');
      setGpa(student.gpa ? student.gpa.toString() : '');

      setStudentLoaded(true);
    } catch (error) {
      Alert.alert('Error', 'Failed to fetch student data.');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async () => {
    if (
      !stdname ||
      !dob ||
      !degree ||
      !feestatus ||
      !semester ||
      !cgpa ||
      !gpa
    ) {
      Alert.alert('Validation', 'Please fill all fields.');
      return;
    }

    setUpdating(true);

    try {
      const response = await fetch(`${SHEETBEST_BASE_URL}/stdid/${stdid}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          stdname,
          dob,
          degree,
          feestatus,
          semester: parseInt(semester, 10),
          cgpa: parseFloat(cgpa),
          gpa: parseFloat(gpa),
        }),
      });

      if (!response.ok) throw new Error('Update failed');

      Alert.alert('Success', 'Student info updated successfully.');
      navigation.goBack();
    } catch (error) {
      Alert.alert('Error', 'Failed to update student info.');
      console.error(error);
    } finally {
      setUpdating(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
      <Text style={styles.heading}>Edit Student Info</Text>

     
      {!routeStdid && (
        <>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Enter Student ID</Text>
            <TextInput
              value={stdid}
              onChangeText={setStdid}
              placeholder="Enter student ID"
              style={styles.input}
              keyboardType="default"
              autoCapitalize="none"
              editable={!loading && !updating}
            />
          </View>

          <TouchableOpacity
            onPress={fetchStudent}
            style={[styles.button, loading && { backgroundColor: '#7588c9' }]}
            disabled={loading || updating}
          >
            <Text style={styles.buttonText}>{loading ? 'Loading...' : 'Search'}</Text>
          </TouchableOpacity>
        </>
      )}

      {loading && (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color="#4a69bd" />
        </View>
      )}

      {studentLoaded && !loading && (
        <>
          {[
            { label: 'Name', value: stdname, setter: setStdname, placeholder: 'Enter student name' },
            { label: 'Date of Birth', value: dob, setter: setDob, placeholder: 'YYYY-MM-DD' },
            { label: 'Degree', value: degree, setter: setDegree, placeholder: 'Enter degree' },
            { label: 'Fee Status', value: feestatus, setter: setFeestatus, placeholder: 'paid/unpaid' },
            { label: 'Semester', value: semester, setter: setSemester, placeholder: 'Enter semester', keyboardType: 'numeric' },
            { label: 'CGPA', value: cgpa, setter: setCgpa, placeholder: 'Enter CGPA', keyboardType: 'numeric' },
            { label: 'GPA', value: gpa, setter: setGpa, placeholder: 'Enter GPA', keyboardType: 'numeric' },
          ].map(({ label, value, setter, placeholder, keyboardType }, idx) => (
            <View key={idx} style={styles.inputGroup}>
              <Text style={styles.label}>{label}</Text>
              <TextInput
                value={value}
                onChangeText={setter}
                placeholder={placeholder}
                style={styles.input}
                keyboardType={keyboardType || 'default'}
                autoCapitalize="none"
                editable={!updating}
              />
            </View>
          ))}

          <TouchableOpacity
            onPress={handleUpdate}
            style={[styles.button, updating && { backgroundColor: '#7588c9' }]}
            disabled={updating}
          >
            <Text style={styles.buttonText}>{updating ? 'Updating...' : 'Update Student'}</Text>
          </TouchableOpacity>
        </>
      )}

      <TouchableOpacity onPress={() => navigation.goBack()} style={[styles.button, styles.backButton]}>
        <Text style={[styles.buttonText, styles.backButtonText]}>Go Back</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    paddingBottom: 40,
    backgroundColor: '#f4f6f7',
    flexGrow: 1,
  },
  heading: {
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 20,
    color: '#34495e',
    textAlign: 'center',
  },
  inputGroup: {
    marginBottom: 15,
  },
  label: {
    fontWeight: '600',
    marginBottom: 6,
    fontSize: 16,
    color: '#2d3436',
  },
  input: {
    borderWidth: 1,
    borderColor: '#dcdde1',
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 8,
    fontSize: 16,
    color: '#2f3640',
  },
  button: {
    backgroundColor: '#4a69bd',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 20,
    shadowColor: '#2c3e50',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  buttonText: {
    color: '#f1f2f6',
    fontWeight: '700',
    fontSize: 18,
  },
  backButton: {
    backgroundColor: '#95a5a6',
    marginTop: 12,
  },
  backButtonText: {
    color: '#2f3640',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
});

export default Editstudent;
