import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { Ionicons, MaterialIcons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');
const cardSize = (width - 60) / 2;

export default function CourseOptionsScreen({ navigation }) {
  return (
    <View style={styles.container}>
  
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Ionicons name="arrow-back" size={24} color="#1e3799" />
        <Text style={styles.backText}>Back</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Course Management</Text>

      <View style={styles.grid}>
        <TouchableOpacity
          style={styles.card}
          onPress={() => navigation.navigate('CourseAdd')}
        >
          <Ionicons name="add-circle" size={40} color="#fff" />
          <Text style={styles.cardText}>Add Course</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.card}
          onPress={() => navigation.navigate('CourseDel')}
        >
          <MaterialIcons name="delete" size={40} color="#fff" />
          <Text style={styles.cardText}>Delete Course</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.card}
          onPress={() => navigation.navigate('Courseinfo')}
        >
          <MaterialIcons name="info" size={40} color="#fff" />
          <Text style={styles.cardText}>Course Info</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f4f6f7' },
  backButton: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  backText: { marginLeft: 6, fontSize: 16, color: '#1e3799', fontWeight: '600' },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#0a3d62',
    marginBottom: 30,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  card: {
    width: cardSize,
    height: cardSize * 0.8,
    backgroundColor: '#4a69bd',
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    elevation: 8,
  },
  cardText: {
    fontSize: 18,
    color: '#f1f2f6',
    fontWeight: '600',
    textAlign: 'center',
    marginTop: 10,
  },
});
