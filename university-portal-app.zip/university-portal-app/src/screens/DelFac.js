import React, { useState } from 'react';
import {
  View,
  TextInput,
  Text,
  Alert,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function DeleteFaculty({ navigation }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [faculties, setFaculties] = useState([]);
  const [loading, setLoading] = useState(false);

  const endpoint = 'https://api.sheetbest.com/sheets/560bd63f-eade-4c48-96da-452c0495857e';

  const handleSearchAndDelete = async (idToDelete) => {
    if (!idToDelete.trim()) {
      Alert.alert('Error', 'Please enter Faculty ID to delete');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(endpoint);
      if (!response.ok) {
        Alert.alert('Error', 'Failed to fetch faculty data');
        setLoading(false);
        return;
      }

      const data = await response.json();

      const rowIndex = data.findIndex(
        (faculty) => String(faculty.FacId).trim() === idToDelete.trim()
      );

      if (rowIndex === -1) {
        Alert.alert('Not found', `Faculty ID "${idToDelete}" not found`);
        setLoading(false);
        return;
      }

      const deleteUrl = `${endpoint}/${rowIndex}`;
      const deleteResponse = await fetch(deleteUrl, { method: 'DELETE' });

      if (deleteResponse.ok) {
        Alert.alert('Success', `Faculty ID "${idToDelete}" deleted successfully.`);
        setFaculties((prev) => prev.filter((f) => String(f.FacId).trim() !== idToDelete.trim()));
        setSearchTerm('');
      } else {
        const errorText = await deleteResponse.text();
        Alert.alert('Delete failed', errorText);
      }
    } catch (error) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Ionicons name="arrow-back" size={24} color="#1e3799" />
        <Text style={styles.backButtonText}>Go Back</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Delete Faculty</Text>

      <View style={styles.form}>
        <TextInput
          placeholder="Enter Faculty ID to Delete"
          value={searchTerm}
          onChangeText={setSearchTerm}
          style={styles.input}
          onSubmitEditing={() => handleSearchAndDelete(searchTerm)}
          editable={!loading}
        />

        <TouchableOpacity
          style={styles.button}
          onPress={() => handleSearchAndDelete(searchTerm)}
          disabled={loading}
        >
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Delete</Text>}
        </TouchableOpacity>

        {faculties.length > 0 && (
          <View style={styles.results}>
            {faculties.map((faculty) => (
              <View key={String(faculty.FacId)} style={styles.facultyCard}>
                <Text style={styles.facultyText}>ID: {faculty.FacId}</Text>
                <Text style={styles.facultyText}>Name: {faculty.FacName}</Text>
                <Text style={styles.facultyText}>DOB: {faculty.dob}</Text>
                <Text style={styles.facultyText}>Department: {faculty.Department}</Text>
                <Text style={styles.facultyText}>Email: {faculty.Email}</Text>
              </View>
            ))}
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 24, backgroundColor: '#f2f4f7', flexGrow: 1 },
  backButton: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  backButtonText: { marginLeft: 6, fontSize: 16, color: '#1e3799', fontWeight: '600' },
  title: { fontSize: 28, fontWeight: '700', textAlign: 'center', color: '#1e3799', marginBottom: 24 },
  form: { backgroundColor: '#fff', padding: 20, borderRadius: 16, elevation: 6 },
  input: {
    borderWidth: 1,
    borderColor: '#ced6e0',
    borderRadius: 12,
    padding: 12,
    fontSize: 16,
    marginBottom: 16,
    backgroundColor: '#f8f9fa',
  },
  button: {
    backgroundColor: '#eb3b5a',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 20,
  },
  buttonText: { color: '#f1f2f6', fontSize: 18, fontWeight: 'bold' },
  results: { marginTop: 10 },
  facultyCard: {
    backgroundColor: '#dff9fb',
    padding: 15,
    borderRadius: 12,
    marginBottom: 12,
  },
  facultyText: { fontSize: 16, marginBottom: 4, color: '#130f40' },
});
