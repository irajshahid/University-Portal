import React, { useEffect } from 'react';
import {
  View,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
} from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import { useSelector, useDispatch } from 'react-redux';
import { fetchSheetData } from '../feature/PortalSlice';
const CoursesScreen = ({ navigation }) => {
  const dispatch = useDispatch();

  const courses = useSelector(state => Array.isArray(state.portal.sheetData) ? state.portal.sheetData : []);
  const loading = useSelector(state => state.portal.loading);
  const error = useSelector(state => state.portal.error);

  const currentUser = useSelector(state => state.user.currentUser); 

  useEffect(() => {
    dispatch(fetchSheetData());
  }, [dispatch]);

  if (!currentUser || !currentUser.email) {
    return (
      <View style={styles.centered}>
        <Text>User not logged in</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.centered}>
        <Text style={styles.error}>Error: {error}</Text>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={styles.centered}>
        <Text>Loading courses...</Text>
      </View>
    );
  }

  const filteredCourses = courses.filter(course =>
    course.email?.trim().toLowerCase() === currentUser.email.trim().toLowerCase()
  );

  if (filteredCourses.length === 0) {
    return (
      <View style={styles.centered}>
        <Text>No courses found for this student</Text>
      </View>
    );
  }

  const firstCourse = filteredCourses[0];

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <AntDesign name="arrowleft" size={24} color="#0a3d62" />
        <Text style={styles.backText}>Go Back</Text>
      </TouchableOpacity>

      <View style={styles.card}>
        <Text style={styles.courseCode}>{firstCourse.coursecode}</Text>
        <Text style={styles.courseTitle}>{firstCourse.coursetitle}</Text>
      </View>
    </ScrollView>
  );
};


const styles = StyleSheet.create({
  container: {
    padding: 16,
    paddingBottom: 80,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  backText: {
    fontSize: 16,
    color: '#0a3d62',
    marginLeft: 8,
  },
  card: {
    backgroundColor: '#dff9fb',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  courseCode: {
    fontWeight: 'bold',
    fontSize: 16,
    color: '#130f40',
  },
  courseTitle: {
    fontSize: 14,
    color: '#30336b',
  },
  error: {
    color: 'red',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
});

export default CoursesScreen;
