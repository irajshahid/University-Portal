import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
  
} from 'react-native';
import { Picker } from '@react-native-picker/picker';

export default function RequestFeatureScreen({ navigation }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('Student');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState('Medium');
  const [category, setCategory] = useState('Other');

  const endpoint = 'https://api.sheetbest.com/sheets/560bd63f-eade-4c48-96da-452c0495857e';

  const handleSubmit = async () => {
    if (!title || !description) {
      Alert.alert('Error', 'Title and Description are required.');
      return;
    }

    const requestData = {
      Name: name,
      Email: email,
      Role: role,
      Title: title,
      Description: description,
      Priority: priority,
      Category: category,
    };

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData),
      });
      if (response.ok) {
        Alert.alert('Success', 'Feature request submitted.');
        navigation.goBack();
      } else {
        Alert.alert('Error', 'Failed to submit request.');
      }
    } catch (error) {
      Alert.alert('Error', 'Submission failed.');
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Text style={styles.backButtonText}>← Back</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Request a Feature</Text>

      <TextInput style={styles.input} placeholder="Name (optional)" value={name} onChangeText={setName} />
      <TextInput style={styles.input} placeholder="Email (optional)" value={email} onChangeText={setEmail} keyboardType="email-address" />

      <Text style={styles.label}>Role</Text>
      <Picker selectedValue={role} onValueChange={setRole} style={styles.picker}>
        <Picker.Item label="Student" value="Student" />
        <Picker.Item label="Faculty" value="Faculty" />
        <Picker.Item label="Admin" value="Admin" />
      </Picker>

      <TextInput style={styles.input} placeholder="Feature Title" value={title} onChangeText={setTitle} />
      <TextInput style={[styles.input, { height: 100 }]} multiline placeholder="Feature Description" value={description} onChangeText={setDescription} />

      <Text style={styles.label}>Priority</Text>
      <Picker selectedValue={priority} onValueChange={setPriority} style={styles.picker}>
        <Picker.Item label="Low" value="Low" />
        <Picker.Item label="Medium" value="Medium" />
        <Picker.Item label="High" value="High" />
      </Picker>

      <Text style={styles.label}>Category</Text>
      <Picker selectedValue={category} onValueChange={setCategory} style={styles.picker}>
        <Picker.Item label="UI" value="UI" />
        <Picker.Item label="Admin Panel" value="Admin Panel" />
        <Picker.Item label="Student Portal" value="Student Portal" />
        <Picker.Item label="Performance" value="Performance" />
        <Picker.Item label="Other" value="Other" />
      </Picker>

      <TouchableOpacity style={styles.button} onPress={handleSubmit}>
        <Text style={styles.buttonText}>Submit Request</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#f2f4f7',
    flexGrow: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    color: '#0a3d62',
  },
  input: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 10,
    marginBottom: 15,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#dcdde1',
  },
  picker: {
    backgroundColor: '#fff',
    borderRadius: 10,
    marginBottom: 15,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#34495e',
    marginBottom: 6,
  },
  button: {
    backgroundColor: '#4a69bd',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 10,
    elevation: 4,
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 18,
  },
  backButton: {
    marginBottom: 10,
  },
  backButtonText: {
    color: '#1e3799',
    fontSize: 16,
  },
});
