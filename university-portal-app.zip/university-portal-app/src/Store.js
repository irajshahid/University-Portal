import { configureStore } from '@reduxjs/toolkit';
import portalReducer from './feature/PortalSlice';
import userReducer from './feature/UserSlice'; 

const store = configureStore({
  reducer: {
    portal: portalReducer,
    user: userReducer,
  },
});

export default store;
