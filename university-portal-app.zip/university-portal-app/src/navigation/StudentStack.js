import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import Dash from '../screens/Dash'; 
import Course from '../screens/Course';
import CoursesScreen from '../screens/CoursesScreen';
import AttendanceScreen from '../screens/AttendanceScreen';
import InvoicesScreen from '../screens/InvoicesScreen';

const Stack = createNativeStackNavigator();

export default function StudentStack() {
  return (
    <Stack.Navigator
      initialRouteName="Dashboard" 
      screenOptions={{ headerShown: false }}
    >
      <Stack.Screen name="Dashboard" component={Dash} />
    
         <Stack.Screen name="CoursesScreen" component={CoursesScreen} />
      <Stack.Screen name="AttendanceScreen" component={AttendanceScreen} />
      <Stack.Screen name="InvoicesScreen" component={InvoicesScreen} />
 
    </Stack.Navigator>
  );
}
