import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from 'react-native';
import {
  createDrawerNavigator,
  DrawerContentScrollView,
  DrawerItemList,
} from '@react-navigation/drawer';

import {
  MaterialIcons,
  FontAwesome5,
  Ionicons,
  Entypo,
} from '@expo/vector-icons';

import Dashbboard from '../screens/Dashbboard';
import AddStudent from '../screens/AddStudent';
import Deletestudent from '../screens/Deletestudent';
import Faculty from '../screens/Faculty';
import AddFac from '../screens/AddFac';
import DelFac from '../screens/DelFac';
import CourseAdd from '../screens/CourseAdd';
import Course from '../screens/Course';
import CourseDel from '../screens/CourseDel';
import Courseinfo from '../screens/Courseinfo';
import FacultyInfo from '../screens/FacultyInfo';
import StudentInfo from '../screens/StudentInfo';
import Feature from '../screens/Feature';
import Notf from '../screens/Notf';
import ProfileScreen from '../screens/ProfileScreen';
import Editstudent from '../screens/Editstudent';
import Editfac from '../screens/Editfac';

const Drawer = createDrawerNavigator();

function CustomDrawerContent(props) {

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel' },
        {
          text: 'Logout',
          onPress: () => {
     <View style={styles.logoutButton}>
  <TouchableOpacity onPress={handleLogout} style={styles.logoutButton}>
    <Ionicons name="log-out-outline" size={20} color="#fff" />
    <Text style={styles.logoutText}>Logout</Text>
  </TouchableOpacity>
</View>

            
          },
          style: 'destructive',
        },
      ],
      { cancelable: true }
    );
  };

  return (
    <DrawerContentScrollView {...props} contentContainerStyle={{ flex: 1 }}>
      <View style={styles.drawerHeader}>
        <Entypo name="user" size={64} color="#4a69bd" />
        <Text style={styles.drawerUsername}>Admin User</Text>
      </View>
      <DrawerItemList {...props} />
    </DrawerContentScrollView>
  );
}

export default function AdminStack() {
  return (
    <Drawer.Navigator
      drawerContent={(props) => <CustomDrawerContent {...props} />}
      screenOptions={{
        headerShown: true,
        drawerActiveTintColor: '#f39c12',
        drawerInactiveTintColor: '#333',
        drawerLabelStyle: { fontWeight: '600', fontSize: 16 },
        drawerStyle: {
          backgroundColor: '#f8fafc',
          width: 280,
        },
      }}
    >
      <Drawer.Screen
        name="Dashboard"
        component={Dashbboard}
        options={{
        drawerIcon: ({ color }) => (
  <MaterialIcons name="dashboard" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Add Student"
        component={AddStudent}
        options={{
          drawerIcon: ({ color }) => (
            <MaterialIcons name="person-add" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Delete Student"
        component={Deletestudent}
        options={{
          drawerIcon: ({ color }) => (
            <MaterialIcons name="person-remove" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Edit Student"
        component={Editstudent}
        options={{
          drawerIcon: ({ color }) => (
            <MaterialIcons name="edit" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Faculty"
        component={Faculty}
        options={{
          drawerIcon: ({ color }) => (
            <MaterialIcons name="people" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Add Faculty"
        component={AddFac}
        options={{
          drawerIcon: ({ color }) => (
            <MaterialIcons name="person-add" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Delete Faculty"
        component={DelFac}
        options={{
          drawerIcon: ({ color }) => (
            <MaterialIcons name="person-remove" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Edit Faculty"
        component={Editfac}
        options={{
          drawerIcon: ({ color }) => (
            <MaterialIcons name="edit" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Courses"
        component={Course}
        options={{
          drawerIcon: ({ color }) => (
            <FontAwesome5 name="book-open" size={20} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Add Course"
        component={CourseAdd}
        options={{
          drawerIcon: ({ color }) => (
            <MaterialIcons name="add-box" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Delete Course"
        component={CourseDel}
        options={{
          drawerIcon: ({ color }) => (
            <MaterialIcons name="delete" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Course Info"
        component={Courseinfo}
        options={{
          drawerIcon: ({ color }) => (
            <Ionicons name="information-circle-outline" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Faculty Info"
        component={FacultyInfo}
        options={{
          drawerIcon: ({ color }) => (
            <MaterialIcons name="info" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Features"
        component={Feature}
        options={{
          drawerIcon: ({ color }) => (
            <MaterialIcons name="star" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Notifications"
        component={Notf}
        options={{
          drawerIcon: ({ color }) => (
            <Ionicons name="notifications" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Student Information"
        component={StudentInfo}
        options={{
          drawerIcon: ({ color }) => (
            <Entypo name="user" size={22} color={color} />
          ),
        }}
      />
    </Drawer.Navigator>
  );
}

const styles = StyleSheet.create({
  drawerHeader: {
    padding: 20,
    backgroundColor: '#4a69bd',
    alignItems: 'center',
    marginBottom: 10,
    borderBottomLeftRadius: 15,
    borderBottomRightRadius: 15,
  },
  drawerUsername: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
    marginTop: 8,
  },
  logoutButton: {
    marginTop: 'auto',
    backgroundColor: '#eb3b5a',
    marginHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  logoutText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 16,
  },
});
